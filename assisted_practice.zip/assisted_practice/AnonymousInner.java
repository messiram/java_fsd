package assistedprojects;
abstract class AnonymousInnerClassDemo {
	   public abstract void display();
	}
public class AnonymousInner {
public static void main(String[] args) {
		AnonymousInnerClassDemo s = new AnonymousInnerClassDemo() {

		         public void display() {
		            System.out.println("Anonymous Inner Class");
		         }
		      };
		      s.display();
		   }
		}

