package assistedprojects;

public class InnerClassDemo {
		 private String a="Welcome to Java"; 
		 
		 class Inner{  
		  void hello(){
			  System.out.println(a+",  Inner Classes Project");
		  }  
		 }  


		public static void main(String[] args) {

			InnerClassDemo obj=new InnerClassDemo();
			InnerClassDemo.Inner inn=obj.new Inner();  
			inn.hello();  
		}
	
	}



