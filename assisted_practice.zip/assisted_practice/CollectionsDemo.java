package assistedprojects;
import java.util.*;
public class CollectionsDemo {
		public static void main(String[] args) {
			//creating arraylist
			System.out.println("ArrayList Demo");
			ArrayList<String> fruits=new ArrayList<String>();   
		      fruits.add("apple");//
		      fruits.add("Mango");    	   
		      System.out.println(fruits);  
						
			//creating linkedlist
		      System.out.println("\n");
		      System.out.println("LinkedList Demo");
		      LinkedList<String> n=new LinkedList<String>();  
		      n.add("Sriram");  
		      n.add("Master");  	      
		      Iterator<String> ite=n.iterator();  
		      while(ite.hasNext()){  
		       System.out.println(ite.next());  
		       
		       //creating hashset
		       System.out.println("\n");
		       System.out.println("HashSet Demo");
		       HashSet<Integer> b=new HashSet<Integer>();  
		       b.add(100);  
		       b.add(101);  
		       b.add(103);
		       b.add(102);
		       System.out.println(b);
		       
		       //creating linkedhashset
		       System.out.println("\n");
		       System.out.println("LinkedHashSet Demo");
		       LinkedHashSet<Integer> c=new LinkedHashSet<Integer>();  
		       c.add(21);  
		       c.add(23);  
		       c.add(22);
		       c.add(24);	       
		       System.out.println(c);
		      	} 
		      }  
		}
