package assistedprojects;
import java.util.regex.*;
public class Regex {

	public static void main(String[] args) {

		String pat = "[a-z]+";
		String che = "Regular Expressions";
		Pattern pa = Pattern.compile(pat);
		Matcher c = pa.matcher(che);
		
		while (c.find())
	      	System.out.println( che.substring( c.start(), c.end() ) );
		}
	}

