package assistedprojects;
public class explicittypecast {
	public static void main(String[] args) {
	double a= 23.67;
	int b=(int) a;
	System.out.println(" Double "+a+" to int "+ b + "to short");
	}

}