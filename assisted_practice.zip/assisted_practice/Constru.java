package assistedprojects;

public class Constru {		
		int stuId;
		String stuName;
		String department;
		float CGPA;
		
		//default constructor
		public Constru() {
			stuId=1001;
			stuName="Sriram";
			department="ECE";
			CGPA=7;
		}
		
		//parametrized constructor
		public Constru(int stuId,String stuName,String department,float CGPA) {
			this.stuId=stuId;
			this.stuName=stuName;
			this.department=department;
			this.CGPA=CGPA;
		}
		
		public void display() {
			System.out.println("Id: "+stuId);
			System.out.println("Name: "+stuName);
			System.out.println("Department: "+department);
			System.out.println("CGPA: "+CGPA);
			System.out.println();
			
		}
		
		public static void main(String[] args) {
			
			Constru s= new Constru();
			Constru s1= new Constru(12, "Sriram", "ECE", 8); 

			//calling default constructor
			s.display();
			//parametrized constructor
			s1.display();
			
			 
		
		}

		
	}
