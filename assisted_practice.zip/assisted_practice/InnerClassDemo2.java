package assistedprojects;

public class InnerClassDemo2 {
		private String a="Inner Classes project";

		 void display(){  
			 class Inner{  
				 void msg(){
					 System.out.println(a);
				 }  
		  }  
		  
		  Inner l=new Inner();  
		  l.msg();  
		 }  

		 
		public static void main(String[] args) {
			InnerClassDemo2  ob=new InnerClassDemo2 ();  
			ob.display();  
			}


	}
