package assistedprojects;

public class accessmodifiers {
		public void accessmethodPublic() {
			System.out.println("This is public method");
		}
		
		private void accessmethodPrivate() {
			System.out.println("This is private method");
		}
		
		void accessmethodDefault() {
			System.out.println("This is default method");
		}
		
		protected void accessmethodProtected() {
			System.out.println("This is protected method");
		}
		
		//same class able to aceess all types of modifiers
		public static void main(String[] args) {
			
			accessmodifiers obj1= new  accessmodifiers();
			
			obj1.accessmethodDefault();
			obj1.accessmethodPrivate();
			obj1.accessmethodProtected();
			obj1.accessmethodPublic();
			
		
		}
	}
