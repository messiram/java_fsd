package assistedprojects;

public class methodscalling{
	
		 public void methodDisplay() {
			System.out.println("you have called display method");
		 }
		 // int method should have return type
		 public int numberMethod() {
			 
			 int s=85;
			 return s;
		 }
		
		 public static void main(String[] args) {
			 
			 methodscalling obj1= new methodscalling();
			 obj1.methodDisplay();
			 
			 int result=obj1.numberMethod();
			 
			 System.out.println(result);
			
		}
	}

