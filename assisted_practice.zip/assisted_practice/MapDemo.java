package assistedprojects;
import java.util.*;
public class MapDemo {
			public static void main(String[] args) {
		//HashMap 
			HashMap<Integer,String> hama=new HashMap<Integer,String>();      
		      hama.put(1,"Sriram");    
		      hama.put(2,"Master");    
		      hama.put(3,"Vikram");   
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for(Map.Entry<Integer,String> m:hama.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		      
		     //HashTable
		       
		      Hashtable<Integer,String> hata=new Hashtable<Integer,String>();  
		      
		      hata.put(4,"Rolex");  
		      hata.put(5,"Amar");  
		      hata.put(6,"Santhosh");  
		      hata.put(7,"Rahul");  

		      System.out.println("\nThe elements of HashTable are ");  
		      for(Map.Entry<Integer,String> n:hata.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      
		      //TreeMap
		      
		      TreeMap<Integer,String> maptr=new TreeMap<Integer,String>();    
		      maptr.put(8,"Abi");    
		      maptr.put(9,"james");    
		      maptr.put(10,"Catie");       
		      
		      System.out.println("\nThe elements of TreeMap are ");  
		      for(Map.Entry<Integer,String> l:maptr.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
		   }  
}
