package assistedprojects;

public class ArrayDemo {
			public static void main(String[] args) {
			//single dimensional array
			System.out.println("Array: Single Dimensional array");
			int arr1[]= {1,2,5,9,4};
			for(int i=0;i<4;i++) {
				System.out.println("Elements of the array arr1 :"+arr1[i]);
			}
			//multi dimensional array
			System.out.println("\n");
			System.out.println("Array: Multi Dimensional array");
			int arr2[][]= {
					{10,9,8,7},
					{6,5,4,3,2}};
			System.out.println("number of elements in row 1 = "+arr2[0].length+
					"\n number of elements in row 2 = "+arr2[1].length);

			}
		}



