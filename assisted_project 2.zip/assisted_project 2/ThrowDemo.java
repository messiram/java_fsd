package assistedprojects_2;
import java.util.Scanner;

public class ThrowDemo {	
        @SuppressWarnings("resource")
		public static void main(String[] args)
        {
           int a;
           int b;
           int rs;
           Scanner sc = new Scanner(System.in);
           a=sc.nextInt();
           b=sc.nextInt();
            try
            {
                if(b==0) {        
                    throw(new ArithmeticException("Can't divide by zero."));
                }
                else
                {
                    rs = a / b;
                    System.out.print("\n\tThe result is : " + rs);
                }
            }
            catch(ArithmeticException Ex)
            {
                System.out.print("\n\tError : " + Ex.getMessage());
            }

            System.out.print("\n\tEnd of program.");
            sc.close();
        } 
  
    }
