package assistedprojects_2;

public class TryandCatchDemo {

	    public static void main(String args[]) 
	    {
	        int[] arr1 = new int[5];
	        try 
	        {
	            arr1[7] = 5;
	        }
	        catch (ArrayIndexOutOfBoundsException e) 
	        {
	            System.out.println("Array index is out of bounds!"); 
	        }
	        finally 
	        {
	            System.out.println("The array is of size " + arr1.length);
	        }
	    }
	}
