package assistedprojects_2;

public class ThreadDemo2 implements Runnable {
	//implement run method
		public  void run() {
		for(int i=1; i<5; i++) {
		System.out.println(i+ " "+Thread.currentThread().getName());
		 try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} // 1000 milliseconds = 1second
			}			 
		}
				
		public static void main(String[] args) {
			//create target of runnable interface
			ThreadDemo2 inst1= new ThreadDemo2();
			ThreadDemo2 inst2= new ThreadDemo2();
			//create threads  by passing runnable targets in constructor
			Thread th1=new  Thread(inst1);
			Thread th2=new  Thread(inst2);
			th1.setName("First");
			th2.setName("Second");
			th1.start();
			th2.start();
		}

	}
