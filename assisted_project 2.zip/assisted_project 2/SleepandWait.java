package assistedprojects_2;

public class SleepandWait {		
		private static Object LOCK1= new Object();		
		public static void main(String[] args) {		
		try {					
		Thread.sleep(1000);
		System.out.println(Thread.currentThread().getName()+ " is  woke up after "
							+ "1 second  of  sleep");
					
		synchronized (LOCK1) {
		LOCK1.wait(2000);
		System.out.println("Object is woke up after wait of  2 seconds");
		}
		} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("Error Occured: "+e);
		}
		}
	}
