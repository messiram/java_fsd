package assistedprojects_2;

	class bike
		{ 
		    public int gear; 
		    public int speed; 
		    public bike(int gear, int speed) 
		    { 
		        this.gear = gear; 
		        this.speed = speed; 
		    } 
		    public void applyBrake(int decrement) 
		    { 
		        speed -= decrement; 
		    } 
		    public void speedUp(int increment) 
		    { 
		        speed += increment; 
		    }  
		    public String toString()  
		    { 
		        return("No of gears are " + gear + "\n" + "speed of the bike is " + speed); 
		    }  
		} 
		class yamaha extends bike 
		{ 
		    public String Colour ; 
		    public yamaha(int gear,int speed,String bikeColour) 
		    {  
		        super(gear, speed); 
		        Colour  = bikeColour; 
		    }  
		    public void colour(String newValue) 
		    { 
		        Colour = newValue; 
		    } 
		    @Override
		    public String toString() 
		    { 
		        return (super.toString()+ 
		                "\ncolour is "+Colour ); 
		    } 
		}
		public class InheritDemo 
		{ 
		    public static void main(String args[])  
		    { 
		    	yamaha y1 = new yamaha(6, 100, "blue"); 
		        System.out.println(y1.toString());
		    }

}
