package assistedprojects_2;
	class Encapsulate 
	{ 
	    private String Name;  
	    private int id;
	    public int getid()  
	    { 
	      return id; 
	    } 
	    public String getName()  
	    { 
	      return Name; 
	    }  
	    public void setAge( int newid) 
	    { 
	      id = newid; 
	    } 
	    public void setName(String newName) 
	    { 
	      Name = newName; 
	    } 
	}
	public class TestEncapsulation 
	{     
	    public static void main (String[] args)  
	    { 
	        Encapsulate obj = new Encapsulate(); 
	        obj.setName("Master"); 
	        obj.setAge(10);  
	        System.out.println("My name : " + obj.getName()); 
	        System.out.println("My id : " + obj.getid());     
	    }
	}
	   
