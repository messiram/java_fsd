package assistedprojects_2;

public class PolymorphDemo {
		    public int add(int x, int y) 
		    { 
		        return (x + y); 
		    } 
		    public int add(int x, int y, int z) 
		    { 
		        return (x + y + z); 
		    } 
		    public double add(double x, double y) 
		    { 
		        return (x + y); 
		    } 
		    public static void main(String args[]) 
		    { 
		    	PolymorphDemo p = new PolymorphDemo(); 
		        System.out.println(p.add(10, 10)); 
		        System.out.println(p.add(10, 26, 29)); 
		        System.out.println(p.add(10.5, 50.5)); 
		    } 
}
