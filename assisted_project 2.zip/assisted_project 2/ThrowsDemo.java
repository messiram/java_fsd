package assistedprojects_2;
import java.util.Scanner;
public class ThrowsDemo {
        void Division() throws ArithmeticException
        {
            int a;
            int b;
            int rs;
            Scanner sc=new Scanner(System.in);
            a=sc.nextInt();
            b=sc.nextInt();
            rs = a / b;
            System.out.print("\n\tThe result is : " + rs);
            sc.close();
        }
         public static void main(String[] args)
        {
        	 ThrowsDemo T = new ThrowsDemo();
             try
            {
                T.Division();
            }
            catch(ArithmeticException Ex)
            {
                System.out.print("\n\tError : " + Ex.getMessage());
            }
            System.out.print("\n\tEnd of program.");
        }
    }
