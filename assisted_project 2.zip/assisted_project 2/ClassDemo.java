package assistedprojects_2;

public class ClassDemo {
		    String name; 
		    String Department; 
		    int age; 
		    String Sports; 
		    public ClassDemo(String name, int age, String Sports) 
		    { 
		        this.name = name; 
		        this.age = age; 
		        this.Sports = Sports; 
		    } 
		    public String getName() 
		    { 
		        return name; 
		    } 
		    public int getAge() 
		    { 
		        return age; 
		    } 
		    public String getSports() 
		    { 
		        return Sports; 
		    } 
		    @Override
		    public String toString() 
		    { 
		        return("Hi my name is "+ this.getName()+ ".\nI am " +this.getAge() + " years old.\nI love to play " + this.getSports() + "."); 
		    } 
		    public static void main(String[] args) 
		    { 
		        ClassDemo sriram = new ClassDemo("Sriram", 20, "Football"); 
		        System.out.println(sriram.toString()); 
		    } 
		}
