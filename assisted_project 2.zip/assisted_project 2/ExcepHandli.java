package assistedprojects_2;
@SuppressWarnings("serial")
class handling extends Exception{
	   String s1;
	   handling(String s2) {
		s1=s2;
	   }
	   public String tostring(){ 
		return ("MyException Occurred: "+s1) ;
	   }
	}
public class ExcepHandli {
	 public static void main(String args[]){
			try{
				System.out.println("Starting of try block");
				throw new  handling("This is My error Message");
			}
			catch(handling exp){
				System.out.println("Catch Block") ;
				System.out.println(exp) ;
			}
		   }

}
