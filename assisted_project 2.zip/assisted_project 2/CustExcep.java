package assistedprojects_2;
@SuppressWarnings("serial")
class MyException extends Exception 
{ 
    public MyException(String s1) 
    { 
        super(s1); 
    } 
} 
public class CustExcep {
	    public static void main(String args[]) 
	    { 
	        try
	        { 
	            throw new MyException("temp"); 
	        } 
	        catch (MyException ex) 
	        { 
	            System.out.println("Caught"); 
	            System.out.println(ex.getMessage()); 
	        } 
	    } 
}
