package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.Employee;

public class EmployeeService {
	public String checkUser(String emailid, String password) {
		if(emailid.equals("sriram@gmail.com") && password.equals("12345")) {
			return "success";
		}else {
			return "failure";
		}
	}
	
	public Employee getEmployee() {
		Employee emp=new Employee();
		emp.setId(1);
		emp.setName("sriram");
		emp.setSalary(10000);
		return emp;
	}
	
	public List<Employee> listOfEmployee() {
		
		List<Employee> listOfEmp=new ArrayList<Employee>();
		Employee emp1=new Employee();
		emp1.setId(1);
		emp1.setName("sriram");
		emp1.setSalary(10000);
		
		Employee emp2=new Employee();
		emp2.setId(2);
		emp1.setName("Master");
		emp1.setSalary(20000);
		return listOfEmp;
	}
	
	public float passEmployeeObject(Employee emp) {
		return emp.getSalary();
	}
}
