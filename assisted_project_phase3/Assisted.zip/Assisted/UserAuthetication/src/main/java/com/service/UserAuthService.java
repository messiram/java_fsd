package com.service;

public class UserAuthService {
	public String checkUser(String emailid, String password) {
		if(emailid.equals("master@gmail.com") && password.equals("12345")) {
			return "success";
		}else {
			return "failure";
		}
	}
}
