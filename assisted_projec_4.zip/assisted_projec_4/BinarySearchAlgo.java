package assisted_package_4;
import java.util.Scanner;
public class BinarySearchAlgo
{
	
	public static void main(String[] args) 
	{
		int[] ar1 = {3,6,9,12,15};
        int number;
        int arrlength = ar1.length;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number to search in the array");
        number=sc.nextInt();
        bsearch(ar1,0,number,arrlength);		
        sc.close();
	}

	public static void bsearch(int[] arr, int lb, int number, int ub) {
		
		int midValue= (lb+ub)/2;
		
		while(lb<=ub) {
			
			if(arr[midValue]<number)
			{
				lb= midValue+1;
			}
			else if(arr[midValue]==number)
			{
				System.out.println("Element found at index: "+midValue);
				break;
			}
			else {
				ub=midValue-1;
			}
			midValue=(lb+ub)/2;
		}
		if(lb>ub) {
			System.out.println("Element Not Found");
		}
		
	}

}