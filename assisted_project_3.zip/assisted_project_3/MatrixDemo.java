package assisted_package_3;

public class MatrixDemo {
	
	public static void main(String[] args) {
		
		int ro1=2, co1=3;
		int co2=2;
		
		int [][] firMat= {{9,-2,3},{5,0,4}};
		int [][] secMat= {{1,8},{-6,0},{0,7}};
		
		
		//to multiply the matrix
		
		int[][]  prod= multiplyMatrix(firMat,secMat,ro1,co1,co2);
		
		//display the result of multiplication
		displayresult(prod);
	}
	
	private static int[][] multiplyMatrix(int[][] firstMatrix, int[][] secondMatrix,  int r1,  int c1,int c2)
	{
		
		int[][] result = new int[r1][c2];//  resultant matrix
		
		for(int i=0; i<r1;  i++) {
			
			for(int j=0; j<c2; j++) {
				
				for(int k=0;k<c1;  k++) {
					 result[i][j]+=firstMatrix[i][k]*secondMatrix[k][j];
				}
			}
			
		}
		return result;
	}
	
	private static void displayresult(int [][]product) {
		
		System.out.println("Product of two matrix is : ");
		for(int[] row: product) {
			
			for(int column:row) {
				System.out.print(column+ " ");
			}
			System.out.println();
		}
		
	}

}