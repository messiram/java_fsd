package assisted_package_3;
class Smallestt 
	{ 
	int kthSmallest(int ary1[], int x, int y, int z) 
	    	{ 
	             		if (z > 0 && z <= y - x + 1) 
	        		{ 
	            			int positi = randomPartition(ary1, x, y); 
	            			if (positi-x == z-1) 
	                			return ary1[positi]; 
	            			if (positi-x > z-1) 
	                			return kthSmallest(ary1, x, positi-1, z); 
	            			return kthSmallest(ary1, positi+1, y, z-positi+x-1); 
	        		} 
	        return Integer.MAX_VALUE; 
	    } 
	    void swap(int ary2[], int a, int b) 
	    { 
	        int temp = ary2[a]; 
	        ary2[a] = ary2[b]; 
	        ary2[b] = temp; 
	    } 
	    int partition(int ary3[], int m, int n) 
	    { 
	        int x = ary3[n], i = m; 
	        for (int j = m; j <= n - 1; j++) 
	        { 
	            if (ary3[j] <= x) 
	            { 
	                swap(ary3, i, j); 
	                i++; 
	            } 
	        } 
	        swap(ary3, i, n); 
	        return i; 
	    } 
	    int randomPartition(int ary4[], int l, int r) 
	    { 
	        int n = r-l+1; 
	        int p1 = (int)(Math.random())*(n-1); 
	        swap(ary4, l + p1, r); 
	        return partition(ary4, l, r); 
	    } 
	}  
	public class UnsortedListDemo 
	{
		public static void main(String[] args) {
			Smallestt o1 = new Smallestt(); 	        
	        int arr1[] = {21,3,9,12,45,10}; 
	        int n1 = arr1.length,k1 = 4; 
	        System.out.println("The smallest element of K'th is "+ o1.kthSmallest(arr1, 0, n1-1, k1)); 
	    }
	}
