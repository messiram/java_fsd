package assisted_package_3;
import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo 
{
	
	public static void main(String[] args) {
		Queue<String> Queuelist= new LinkedList<String>();
		
		Queuelist.add("Gokul");
		Queuelist.add("Sriram");
		Queuelist.add("Messi");
		Queuelist.add("Master");
		Queuelist.add("Kiran");
		Queuelist.add("Arun");
		
		System.out.println("Queue is : "+Queuelist);		
		//find head of queue
		System.out.println("Head of the Queue list : "+Queuelist.peek());
		Queuelist.remove();		
		System.out.println("After Removing Head: "+Queuelist);
		
	}

}



