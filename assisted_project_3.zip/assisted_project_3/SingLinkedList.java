package assisted_package_3;
public class SingLinkedList {
	Node head; ///first node
	//inner class
	static class Node{
		int d;
		Node next;
		
		Node(int d1){
			d=d1;
			next=null;
		}
	}	
	//To create a new node
	public static SingLinkedList insert(SingLinkedList list,int data) {
		
		//create a node with the data given		
		Node nodenew= new Node(data);
		nodenew.next=null;
		
		
		///if the linked list is empty, then make the new node as head
		
		if(list.head==null) {
			list.head=nodenew;		
		}else {
			///or it will travels till the last node and insert the new_node there
			Node last=list.head;
			while(last.next!=null) {
				last =last.next;
			}
			
			//Insert the new_node at the last node
			last.next=nodenew;
		}
		
		return list;
	}
	
	
	public static void printList(SingLinkedList list) {
		
		Node currNode= list.head;
		System.out.print("LinkedList: ");
		///travels through linked list
		
		while(currNode!=null) {
			//print the data of current node
			System.out.print(currNode.d +" ");
			
			//go to the next node
			
			currNode=currNode.next;
		}
		
		System.out.println();
	}
	
	//Method to delete a node in the LinkedList by KEY
		public static SingLinkedList deleteByKey(SingLinkedList list, int key) {
			// Store head node
			Node currNode = list.head, prev = null;
			//to delete a first node
			if (currNode != null && currNode.d == key) {
				list.head = currNode.next; // Changed head
				System.out.println(key + " found and deleted");
				return list;
			}
			//to delete node between two nodes or last node
			while (currNode != null && currNode.d != key) {
				prev = currNode;
				currNode = currNode.next;
			} //execute until it founds a key or reaches to the last element of list
			//if key found
			if (currNode != null) {
				prev.next = currNode.next;
				System.out.println(key + " found and deleted");
			}
			//if key not found
			if (currNode == null) {
				System.out.println(key + " not found");
			}
			return list;
		}	
	///prepare singly linked list
	public static void main(String[] args) {
		
		//starts with empty list
		
		SingLinkedList l1 =new SingLinkedList();
		
		//insert the values
		
		l1= insert(l1, 11);
		l1=  insert(l1, 12);
		l1= insert(l1, 13);
		l1= insert(l1, 14);
		l1= insert(l1, 15);
		l1= insert(l1, 16);
		l1= insert(l1, 17);
		l1= insert(l1, 18);

		printList(l1);
		
		
		//delete node
		
		
		//deleting Head
		deleteByKey(l1, 12);
		//print linked list
		printList(l1);
		
		
		//delete by key 4
		deleteByKey(l1, 14);
		//print linked list
		printList(l1);
		
		//delete by key 10-- gives out put that key is not found
		deleteByKey(l1, 20);
		//print linked list
		printList(l1);
		
	}

}