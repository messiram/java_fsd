package assisted_package_3;
	
	class ArrRotation { 
		public void rotat(int[] n, int steps)
		{
		    		if(steps > n.length) 
		    		{
		       			steps = steps%n.length;
		    		}
		    		
		 		int[] res = new int[n.length];
		 		//copies from n[2],n[3].. to res[0],res[1]..
		 		for(int i=0; i < steps; i++)
		 {
		        res[i] = n[n.length-steps+i];
		 }
		 		//copies n[0],n[1] to res[5],res[6], array rotated
		 		int l=0;
		    	for(int i=steps; i<n.length; i++){
		        res[i] = n[l];
		        l++;
		 }
		 		System.arraycopy( res, 0, n, 0, n.length );
		}
		} 
		public class Arraydemo {
		
		public static void main(String[] args) {
				ArrRotation a1 = new ArrRotation();
		        		int arr[] = {5,6,8,3,9,1,2}; 
		        		a1.rotat(arr, 5); 
		        		for(int i=0;i<arr.length;i++){
		            			System.out.print(arr[i]+" ");
		        		}
			}
}
