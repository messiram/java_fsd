package assisted_package_3;

public class CircularLinkedList {
	
	static class Node {
		int d;
		Node next;

		Node(int d1) {
			d = d1;
			next = null;
		}
	}
	Node h;

	CircularLinkedList() {
		h = null;
	}

	void sortedInsert(Node new_node) {
		Node current = h;
		if (current == null) {
			new_node.next = new_node;
			h = new_node;
			
		} 
		
		else if (current.d >= new_node.d) {
			while (current.next != h)
				current = current.next;
			current.next = new_node;
			new_node.next = h;
			h = new_node;
		} else {
			
			while (current.next != h && current.next.d < new_node.d)
				current = current.next;
			new_node.next = current.next;
			current.next = new_node;
		}
	}

	void printLists() {
		if (h != null) {
			Node temp = h;
			do {
				System.out.print(temp.d + " ");
				temp = temp.next;
			} while (temp != h);
		}
	}
	
	public static void main(String[] args) {
		
		CircularLinkedList list = new CircularLinkedList();
		int ar1[] = new int[] { 23, 67, 4, 10, 1, 80 };
		Node tempor = null;
		for (int i = 0; i < 6; i++) {
			tempor = new Node(ar1[i]);
			list.sortedInsert(tempor);
		}
		list.printLists();
	}
}